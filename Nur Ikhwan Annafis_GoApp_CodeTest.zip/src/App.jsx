import './App.css';

import React, { Component } from 'react';
import debounce from 'lodash/debounce';
import { connect } from 'react-redux';
import { fetchData } from '../src/stores/actions/app.action';

class App extends Component {
  constructor(props){
    super(props);
    this.state = {
      limit: 10,
      page: 1
    };

    this.handleSearch = debounce(this.handleSearch, 3000);
  }

  handleSearch = value => {
    const params = {
      model: '',
      content: '',
      search: value.target.value
    }

    this.props.fetchData(params)
  }

  handleGetContent = () => {
    const params = {
      model: '',
      content: ''
    }

    this.props.fetchData(params);
  }

  render() {
    const { data } = this.props;

    return (
      <div style={{ width: '100vh', height: '100vh' }}>
          <button type="button" onClick={this.handleGetContent}>Get Content</button>
          <input type="text" onChange={this.handleSearch} />
          <div style={{ margin: '10px 0px' }}>
            <p>List Data</p>
            <ul>
              {data.listData.map(item => (
                <li>{item.name}</li>
              ))}
            </ul>
          </div> 
      </div>
    );
  }
}

const mapStateToProps = state => ({
  data: state.app
})

export default connect(mapStateToProps, { fetchData })(App);