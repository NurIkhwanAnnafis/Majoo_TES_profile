import {
    FETCH_DATA_REQUEST,
    FETCH_DATA_SUCCESS,
    FETCH_DATA_ERROR,
} from '../actions/app.action';

const initState = {
    isLoadingA: false,
    listDataTopA: [],
    listDataTopB: [],
    listDataTopC: [],
    params: {
        page: 1,
        limit: 
    }
};

export default function appReduce(state = initState, action) {
    switch (action.type) {
        case FETCH_DATA_REQUEST:
            return {
                ...state,
                isLoading: true
            }

    case FETCH_DATA_SUCCESS:
        return {
            ...state,
            isLoading: false,
            listData: action.payload || []
        }

        case FETCH_DATA_ERROR:
            return {
                ...state,
                isLoading: false
            }
    
        default:
            return state;
    }
}
