import httpService from "../../app/http.service";

export const FETCH_DATA_REQUEST = 'FETCH_DATA_REQUEST';
export const FETCH_DATA_SUCCESS = 'FETCH_DATA_SUCCESS';
export const FETCH_DATA_ERROR = 'FETCH_DATA_ERROR';

export function fetchData(params){
    return dispatch => {
        dispatch({ type: FETCH_DATA_REQUEST });
        return httpService.get('/', { params }).then(response => {
            if(response){
                dispatch({ type: FETCH_DATA_SUCCESS, payload: response.data });
                return response
            }
            dispatch({ type: FETCH_DATA_ERROR });
            if(response === false) { //handle 401 from interceptor
                dispatch(logout());
            } 
        })
    }
}